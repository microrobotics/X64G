﻿namespace fusion.Core.Spread
{
    public class Arrays
    {
        
    }
}